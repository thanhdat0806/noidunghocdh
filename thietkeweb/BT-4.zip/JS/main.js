var Result = " ";
// function next() {
//     var Result = 0;
    
//     document.getElementById("Result").value = "" ;
// }
function my(int) {
    
   document.getElementById("y").value += int;
}
function next() {
    var as = eval(document.getElementById("y").value);
    document.getElementById("y").value = as;
} 
